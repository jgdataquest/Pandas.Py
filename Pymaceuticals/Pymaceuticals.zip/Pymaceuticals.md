
## Pymaceuticals Inc.

OBSERVED TREND 1: 
Capomulin has showed the best result in this test. The Tumor volumes reduced over time by 19%.

OBSERVED TREND 2: 
The Tumors all spread using four drugs but Capomulin and Infubinol showing the slower spread rate.

OBSERVED TREND 3:
90% mouse survived using Capomulin. The mouse survival rate using other three drugs are significantly lower.


```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
sns.axes_style('whitegrid')
sns.set_style('whitegrid')
```


```python
#Read files
clinic="Pymaceuticals/raw_data/clinicaltrial_data.csv"
mouse="Pymaceuticals/raw_data/mouse_drug_data.csv"
clinic_pd = pd.read_csv(clinic)
mouse_pd = pd.read_csv(mouse)
#Merge two files
df = pd.merge(clinic_pd, mouse_pd, on=("Mouse ID"))
```


```python
#select 4 drugs in the analyzed list
research_df=df.loc[df["Drug"].isin(['Capomulin', 'Infubinol', 'Ketapril', 'Placebo'])]
#research_df.head()
```


```python
mouse_id_list=research_df.loc[research_df.Timepoint == 45]["Mouse ID"].tolist()
#mouse_id_list
```


```python
#find Mouse ID then data that survivied 45 days.
mouse_id_list=research_df.loc[research_df.Timepoint == 45]["Mouse ID"].tolist()
drug_timepoint_mouse=research_df.loc[research_df['Mouse ID'].isin(mouse_id_list)]
drug_timepoint_mouse.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Mouse ID</th>
      <th>Timepoint</th>
      <th>Tumor Volume (mm3)</th>
      <th>Metastatic Sites</th>
      <th>Drug</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>b128</td>
      <td>0</td>
      <td>45.000000</td>
      <td>0</td>
      <td>Capomulin</td>
    </tr>
    <tr>
      <th>1</th>
      <td>b128</td>
      <td>5</td>
      <td>45.651331</td>
      <td>0</td>
      <td>Capomulin</td>
    </tr>
    <tr>
      <th>2</th>
      <td>b128</td>
      <td>10</td>
      <td>43.270852</td>
      <td>0</td>
      <td>Capomulin</td>
    </tr>
    <tr>
      <th>3</th>
      <td>b128</td>
      <td>15</td>
      <td>43.784893</td>
      <td>0</td>
      <td>Capomulin</td>
    </tr>
    <tr>
      <th>4</th>
      <td>b128</td>
      <td>20</td>
      <td>42.731552</td>
      <td>0</td>
      <td>Capomulin</td>
    </tr>
  </tbody>
</table>
</div>



## Tumor Response to Treatment


```python
#generate a completed Tumor Volume(mm3) dataframe with 5 drogs and 45 days long data
indexed_df = drug_timepoint_mouse.set_index(['Drug','Timepoint'])
Tumor_Response=indexed_df['Tumor Volume (mm3)'].to_frame()
Tumor_Response
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>Tumor Volume (mm3)</th>
    </tr>
    <tr>
      <th>Drug</th>
      <th>Timepoint</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="10" valign="top">Capomulin</th>
      <th>0</th>
      <td>45.000000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>45.651331</td>
    </tr>
    <tr>
      <th>10</th>
      <td>43.270852</td>
    </tr>
    <tr>
      <th>15</th>
      <td>43.784893</td>
    </tr>
    <tr>
      <th>20</th>
      <td>42.731552</td>
    </tr>
    <tr>
      <th>25</th>
      <td>43.262145</td>
    </tr>
    <tr>
      <th>30</th>
      <td>40.605335</td>
    </tr>
    <tr>
      <th>35</th>
      <td>37.967644</td>
    </tr>
    <tr>
      <th>40</th>
      <td>38.379726</td>
    </tr>
    <tr>
      <th>45</th>
      <td>38.982878</td>
    </tr>
    <tr>
      <th rowspan="20" valign="top">Ketapril</th>
      <th>0</th>
      <td>45.000000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>49.470417</td>
    </tr>
    <tr>
      <th>10</th>
      <td>51.368862</td>
    </tr>
    <tr>
      <th>15</th>
      <td>56.184327</td>
    </tr>
    <tr>
      <th>20</th>
      <td>57.935912</td>
    </tr>
    <tr>
      <th>25</th>
      <td>59.548854</td>
    </tr>
    <tr>
      <th>30</th>
      <td>63.599610</td>
    </tr>
    <tr>
      <th>35</th>
      <td>67.211270</td>
    </tr>
    <tr>
      <th>40</th>
      <td>71.150835</td>
    </tr>
    <tr>
      <th>45</th>
      <td>74.104086</td>
    </tr>
    <tr>
      <th>0</th>
      <td>45.000000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>49.048707</td>
    </tr>
    <tr>
      <th>10</th>
      <td>51.582162</td>
    </tr>
    <tr>
      <th>15</th>
      <td>53.675542</td>
    </tr>
    <tr>
      <th>20</th>
      <td>56.530204</td>
    </tr>
    <tr>
      <th>25</th>
      <td>62.108960</td>
    </tr>
    <tr>
      <th>30</th>
      <td>67.104537</td>
    </tr>
    <tr>
      <th>35</th>
      <td>67.873777</td>
    </tr>
    <tr>
      <th>40</th>
      <td>74.106091</td>
    </tr>
    <tr>
      <th>45</th>
      <td>75.294936</td>
    </tr>
    <tr>
      <th>...</th>
      <th>...</th>
      <td>...</td>
    </tr>
    <tr>
      <th rowspan="30" valign="top">Capomulin</th>
      <th>0</th>
      <td>45.000000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>42.261665</td>
    </tr>
    <tr>
      <th>10</th>
      <td>42.992077</td>
    </tr>
    <tr>
      <th>15</th>
      <td>43.529876</td>
    </tr>
    <tr>
      <th>20</th>
      <td>43.967895</td>
    </tr>
    <tr>
      <th>25</th>
      <td>44.596219</td>
    </tr>
    <tr>
      <th>30</th>
      <td>45.261384</td>
    </tr>
    <tr>
      <th>35</th>
      <td>45.941949</td>
    </tr>
    <tr>
      <th>40</th>
      <td>46.821070</td>
    </tr>
    <tr>
      <th>45</th>
      <td>47.685963</td>
    </tr>
    <tr>
      <th>0</th>
      <td>45.000000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>45.622381</td>
    </tr>
    <tr>
      <th>10</th>
      <td>46.414518</td>
    </tr>
    <tr>
      <th>15</th>
      <td>39.804453</td>
    </tr>
    <tr>
      <th>20</th>
      <td>38.909349</td>
    </tr>
    <tr>
      <th>25</th>
      <td>37.695432</td>
    </tr>
    <tr>
      <th>30</th>
      <td>38.212479</td>
    </tr>
    <tr>
      <th>35</th>
      <td>32.562839</td>
    </tr>
    <tr>
      <th>40</th>
      <td>32.947615</td>
    </tr>
    <tr>
      <th>45</th>
      <td>33.329098</td>
    </tr>
    <tr>
      <th>0</th>
      <td>45.000000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>41.408591</td>
    </tr>
    <tr>
      <th>10</th>
      <td>36.825367</td>
    </tr>
    <tr>
      <th>15</th>
      <td>35.464612</td>
    </tr>
    <tr>
      <th>20</th>
      <td>34.255732</td>
    </tr>
    <tr>
      <th>25</th>
      <td>33.118756</td>
    </tr>
    <tr>
      <th>30</th>
      <td>31.758275</td>
    </tr>
    <tr>
      <th>35</th>
      <td>30.834357</td>
    </tr>
    <tr>
      <th>40</th>
      <td>31.378045</td>
    </tr>
    <tr>
      <th>45</th>
      <td>28.430964</td>
    </tr>
  </tbody>
</table>
<p>520 rows × 1 columns</p>
</div>




```python
#Find Avg response for each Drug
drug_timepoint_mouse_mean=drug_timepoint_mouse.groupby(['Drug','Timepoint'])\
                                             ["Tumor Volume (mm3)"].mean()
```


```python
#UnStack the dataframe
drug_timepoint_mouse_mean=drug_timepoint_mouse_mean.unstack(level=0)
drug_timepoint_mouse_mean
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Drug</th>
      <th>Capomulin</th>
      <th>Infubinol</th>
      <th>Ketapril</th>
      <th>Placebo</th>
    </tr>
    <tr>
      <th>Timepoint</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>45.000000</td>
      <td>45.000000</td>
      <td>45.000000</td>
      <td>45.000000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>44.638812</td>
      <td>47.554028</td>
      <td>47.989945</td>
      <td>46.978130</td>
    </tr>
    <tr>
      <th>10</th>
      <td>43.288693</td>
      <td>49.404738</td>
      <td>50.135365</td>
      <td>49.218669</td>
    </tr>
    <tr>
      <th>15</th>
      <td>42.241369</td>
      <td>51.384368</td>
      <td>53.000687</td>
      <td>51.351923</td>
    </tr>
    <tr>
      <th>20</th>
      <td>41.046149</td>
      <td>53.543237</td>
      <td>55.563182</td>
      <td>54.187082</td>
    </tr>
    <tr>
      <th>25</th>
      <td>39.719733</td>
      <td>56.224678</td>
      <td>58.728153</td>
      <td>57.456515</td>
    </tr>
    <tr>
      <th>30</th>
      <td>38.803875</td>
      <td>58.532347</td>
      <td>62.169148</td>
      <td>59.985903</td>
    </tr>
    <tr>
      <th>35</th>
      <td>37.772247</td>
      <td>60.693045</td>
      <td>64.310632</td>
      <td>63.150796</td>
    </tr>
    <tr>
      <th>40</th>
      <td>36.958001</td>
      <td>62.704291</td>
      <td>67.081986</td>
      <td>65.692814</td>
    </tr>
    <tr>
      <th>45</th>
      <td>36.236114</td>
      <td>65.755562</td>
      <td>70.662958</td>
      <td>68.084082</td>
    </tr>
  </tbody>
</table>
</div>




```python
tumor_response_error = drug_timepoint_mouse.groupby(["Drug","Timepoint"])["Tumor Volume (mm3)"].sem()
tumor_response_error=tumor_response_error.unstack(level=0)
tumor_response_error
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Drug</th>
      <th>Capomulin</th>
      <th>Infubinol</th>
      <th>Ketapril</th>
      <th>Placebo</th>
    </tr>
    <tr>
      <th>Timepoint</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>0.373530</td>
      <td>0.400870</td>
      <td>0.388425</td>
      <td>0.334367</td>
    </tr>
    <tr>
      <th>10</th>
      <td>0.707142</td>
      <td>0.483379</td>
      <td>0.299887</td>
      <td>0.547268</td>
    </tr>
    <tr>
      <th>15</th>
      <td>0.811862</td>
      <td>0.630018</td>
      <td>0.552425</td>
      <td>0.790278</td>
    </tr>
    <tr>
      <th>20</th>
      <td>0.846435</td>
      <td>0.866889</td>
      <td>0.751238</td>
      <td>0.992985</td>
    </tr>
    <tr>
      <th>25</th>
      <td>0.895478</td>
      <td>0.942268</td>
      <td>0.751584</td>
      <td>1.184403</td>
    </tr>
    <tr>
      <th>30</th>
      <td>0.979400</td>
      <td>0.977116</td>
      <td>0.949917</td>
      <td>1.283451</td>
    </tr>
    <tr>
      <th>35</th>
      <td>1.102608</td>
      <td>1.069123</td>
      <td>1.225594</td>
      <td>1.213448</td>
    </tr>
    <tr>
      <th>40</th>
      <td>1.223608</td>
      <td>1.062565</td>
      <td>1.410349</td>
      <td>1.327641</td>
    </tr>
    <tr>
      <th>45</th>
      <td>1.223977</td>
      <td>1.144427</td>
      <td>1.453186</td>
      <td>1.351726</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Plot 
```


```python
Capomulin_response = drug_timepoint_mouse_mean['Capomulin']
Infubinol_response = drug_timepoint_mouse_mean['Infubinol']
Ketapril_response = drug_timepoint_mouse_mean['Ketapril']
Placebo_response = drug_timepoint_mouse_mean['Placebo']
```


```python
Capomulin_err = tumor_response_error['Capomulin']
Infubinol_err = tumor_response_error['Infubinol']
Ketapril_err = tumor_response_error['Ketapril']
Placebo_err = tumor_response_error['Placebo']
```


```python
# Create a list of the time(days) that we will use as our x axis
days = drug_timepoint_mouse_mean.index
days
```




    Int64Index([0, 5, 10, 15, 20, 25, 30, 35, 40, 45], dtype='int64', name='Timepoint')




```python
plt.errorbar(days, Capomulin_response, yerr=Capomulin_err, linestyle='--', marker='o', color="red")
plt.errorbar(days, Infubinol_response, yerr=Infubinol_err, linestyle='--', marker='o', color="blue")
plt.errorbar(days, Ketapril_response, yerr=Ketapril_err, linestyle='--', marker='o', color="green")
plt.errorbar(days, Placebo_response, yerr=Placebo_err, linestyle='--', marker='o', color="black")

plt.legend(loc="best")

plt.title("Tumor Response to Treatment")
plt.xlabel("Time(days)")
plt.ylabel("Tumor Volume (mm3)")
# Print our chart to the screen
plt.show()
```


![png](output_16_0.png)


## Metastatic Response to Treatment


```python
#drug_timepoint_mouse
```


```python
#generate a completed Metastatic Sites dataframe with 5 drogs and 45 days long data
indexed_df = drug_timepoint_mouse.set_index(['Drug','Timepoint'])
Metastatic_Response=indexed_df['Metastatic Sites'].to_frame()
Metastatic_Response.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>Metastatic Sites</th>
    </tr>
    <tr>
      <th>Drug</th>
      <th>Timepoint</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="5" valign="top">Capomulin</th>
      <th>0</th>
      <td>0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>0</td>
    </tr>
    <tr>
      <th>10</th>
      <td>0</td>
    </tr>
    <tr>
      <th>15</th>
      <td>0</td>
    </tr>
    <tr>
      <th>20</th>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Find Avg Metastatic Sites response for each Drug
drug_timepoint_mean=drug_timepoint_mouse.groupby(['Drug','Timepoint'])\
                                             ["Metastatic Sites"].mean()
```


```python
#UnStack the dataframe
drug_timepoint_mean=drug_timepoint_mean.unstack(level=0)
drug_timepoint_mean
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Drug</th>
      <th>Capomulin</th>
      <th>Infubinol</th>
      <th>Ketapril</th>
      <th>Placebo</th>
    </tr>
    <tr>
      <th>Timepoint</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>0.190476</td>
      <td>0.111111</td>
      <td>0.545455</td>
      <td>0.545455</td>
    </tr>
    <tr>
      <th>10</th>
      <td>0.380952</td>
      <td>0.666667</td>
      <td>0.909091</td>
      <td>0.909091</td>
    </tr>
    <tr>
      <th>15</th>
      <td>0.428571</td>
      <td>0.666667</td>
      <td>1.181818</td>
      <td>1.454545</td>
    </tr>
    <tr>
      <th>20</th>
      <td>0.714286</td>
      <td>0.666667</td>
      <td>1.636364</td>
      <td>1.909091</td>
    </tr>
    <tr>
      <th>25</th>
      <td>0.857143</td>
      <td>0.777778</td>
      <td>2.181818</td>
      <td>2.272727</td>
    </tr>
    <tr>
      <th>30</th>
      <td>1.095238</td>
      <td>1.333333</td>
      <td>2.545455</td>
      <td>2.545455</td>
    </tr>
    <tr>
      <th>35</th>
      <td>1.190476</td>
      <td>1.555556</td>
      <td>3.000000</td>
      <td>2.909091</td>
    </tr>
    <tr>
      <th>40</th>
      <td>1.380952</td>
      <td>1.888889</td>
      <td>3.090909</td>
      <td>3.090909</td>
    </tr>
    <tr>
      <th>45</th>
      <td>1.476190</td>
      <td>2.111111</td>
      <td>3.363636</td>
      <td>3.272727</td>
    </tr>
  </tbody>
</table>
</div>




```python
drug_timepoint_err=drug_timepoint_mouse.groupby(['Drug','Timepoint'])\
                                             ["Metastatic Sites"].sem()
```


```python
drug_timepoint_err=drug_timepoint_err.unstack(level=0)
drug_timepoint_err
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Drug</th>
      <th>Capomulin</th>
      <th>Infubinol</th>
      <th>Ketapril</th>
      <th>Placebo</th>
    </tr>
    <tr>
      <th>Timepoint</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>0.087805</td>
      <td>0.111111</td>
      <td>0.157459</td>
      <td>0.157459</td>
    </tr>
    <tr>
      <th>10</th>
      <td>0.145997</td>
      <td>0.235702</td>
      <td>0.211254</td>
      <td>0.162623</td>
    </tr>
    <tr>
      <th>15</th>
      <td>0.147542</td>
      <td>0.235702</td>
      <td>0.263480</td>
      <td>0.281672</td>
    </tr>
    <tr>
      <th>20</th>
      <td>0.171031</td>
      <td>0.235702</td>
      <td>0.309625</td>
      <td>0.314918</td>
    </tr>
    <tr>
      <th>25</th>
      <td>0.186263</td>
      <td>0.277778</td>
      <td>0.377026</td>
      <td>0.304240</td>
    </tr>
    <tr>
      <th>30</th>
      <td>0.181328</td>
      <td>0.166667</td>
      <td>0.434085</td>
      <td>0.312283</td>
    </tr>
    <tr>
      <th>35</th>
      <td>0.177537</td>
      <td>0.242161</td>
      <td>0.356753</td>
      <td>0.342572</td>
    </tr>
    <tr>
      <th>40</th>
      <td>0.175610</td>
      <td>0.260579</td>
      <td>0.342572</td>
      <td>0.314918</td>
    </tr>
    <tr>
      <th>45</th>
      <td>0.202591</td>
      <td>0.309320</td>
      <td>0.278722</td>
      <td>0.304240</td>
    </tr>
  </tbody>
</table>
</div>




```python
Capomulin_M_response = drug_timepoint_mean['Capomulin']
Infubinol_M_response = drug_timepoint_mean['Infubinol']
Ketapril_M_response = drug_timepoint_mean['Ketapril']
Placebo_M_response = drug_timepoint_mean['Placebo']
Capomulin_M_err = drug_timepoint_err['Capomulin']
Infubinol_M_err = drug_timepoint_err['Infubinol']
Ketapril_M_err = drug_timepoint_err['Ketapril']
Placebo_M_err = drug_timepoint_err['Placebo']

# Create a list of the time(days) that we will use as our x axis
days = drug_timepoint_mouse_mean.index
```


```python
plt.errorbar(days, Capomulin_M_response, yerr=Capomulin_M_err, linestyle='--', marker='o', color="red")
plt.errorbar(days, Infubinol_M_response, yerr=Infubinol_M_err, linestyle='--', marker='o', color="blue")
plt.errorbar(days, Ketapril_M_response, yerr=Ketapril_M_err, linestyle='--', marker='o', color="green")
plt.errorbar(days, Placebo_M_response, yerr=Placebo_M_err, linestyle='--', marker='o', color="black")

plt.legend(loc=2)

plt.title("Metastatic Spread During Treatment")
plt.xlabel("Time(days)")
plt.ylabel("Met. Sites")

# Print our chart to the screen
plt.show()
```


![png](output_25_0.png)


## Survival Rate


```python
#research_df.head()
```


```python
mouse_id_count=research_df.groupby(['Drug','Timepoint'])["Mouse ID"].count()
```


```python
#UnStack the dataframe
mouse_id_count=mouse_id_count.unstack(level=0)
mouse_id_count
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Drug</th>
      <th>Capomulin</th>
      <th>Infubinol</th>
      <th>Ketapril</th>
      <th>Placebo</th>
    </tr>
    <tr>
      <th>Timepoint</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>25</td>
      <td>25</td>
      <td>25</td>
      <td>25</td>
    </tr>
    <tr>
      <th>5</th>
      <td>25</td>
      <td>25</td>
      <td>23</td>
      <td>24</td>
    </tr>
    <tr>
      <th>10</th>
      <td>25</td>
      <td>21</td>
      <td>22</td>
      <td>24</td>
    </tr>
    <tr>
      <th>15</th>
      <td>24</td>
      <td>21</td>
      <td>19</td>
      <td>20</td>
    </tr>
    <tr>
      <th>20</th>
      <td>23</td>
      <td>20</td>
      <td>19</td>
      <td>19</td>
    </tr>
    <tr>
      <th>25</th>
      <td>22</td>
      <td>18</td>
      <td>19</td>
      <td>17</td>
    </tr>
    <tr>
      <th>30</th>
      <td>22</td>
      <td>17</td>
      <td>18</td>
      <td>15</td>
    </tr>
    <tr>
      <th>35</th>
      <td>22</td>
      <td>12</td>
      <td>17</td>
      <td>14</td>
    </tr>
    <tr>
      <th>40</th>
      <td>21</td>
      <td>10</td>
      <td>15</td>
      <td>12</td>
    </tr>
    <tr>
      <th>45</th>
      <td>21</td>
      <td>9</td>
      <td>11</td>
      <td>11</td>
    </tr>
  </tbody>
</table>
</div>




```python
Capomulin_survival_rate =mouse_id_count['Capomulin']*100/25
Infubinol_survival_rate = mouse_id_count['Infubinol']*100/25
Ketapril_survival_rate = mouse_id_count['Ketapril']*100/25
Placebo_survival_rate = mouse_id_count['Placebo']*100/25
# Create a list of the time(days) that we will use as our x axis
days = drug_timepoint_mouse_mean.index
plt.plot(days, Capomulin_survival_rate, linestyle='--', marker='o', color="red", label="Capomulin")
plt.plot(days, Infubinol_survival_rate, linestyle='--', marker='o', color="blue", label="Infubinol")
plt.plot(days, Ketapril_survival_rate, linestyle='--', marker='o', color="green", label="Ketapril")
plt.plot(days, Placebo_survival_rate, linestyle='--', marker='o', color="black", label="Placebo")

plt.legend(loc="best")

plt.title("Survival During Treatment")
plt.xlabel("Time(days)")
plt.ylabel("Survival Rate(%)")


# Print our chart to the screen
plt.show()
```


![png](output_30_0.png)


## Summary Bar Graph


```python
#drug_timepoint_mouse_mean
```


```python
vol_change = (drug_timepoint_mouse_mean.iloc[-1] - \
                    drug_timepoint_mouse_mean.iloc[0])*100/drug_timepoint_mouse_mean.iloc[0]
#vol_change.to_frame()
```


```python
# Configure plot and ticks
plt.title("Tumor Change Over 45 Days Treament")
plt.ylabel("% Tumor Volume Changes")
plt.ylim(-20, 60)
x=vol_change.index
y=vol_change
colors = ['red' if _y >=0 else 'green' for _y in y]
ax = sns.barplot(x, y, palette=colors)

for n, (label, _y) in enumerate(zip(x, y)):   
    ax.annotate(
        s=(str(round(_y))+"%"),
        xy=(n, 0),
        ha='center',va='center',
        xytext=(0,10),
        textcoords='offset points',
    ) 

plt.tight_layout()
plt.show()
```


![png](output_34_0.png)

